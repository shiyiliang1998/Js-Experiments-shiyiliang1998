# Prospect theory gambles

Author(s): Sam Zorowitz

A jsPsych implementation of prospect theory gambles using icon arrays ([Banchilon et al. 2019](http://arxiv.org/abs/1910.09725)).
