var picArray = [];
var subjcodeArray = [];

picArray[111] = ["images/14.png",
  "images/18.png",
  "images/31.png",
  "images/37.png",
  "images/28.png",
  "images/11.png",
  "images/5.png",
  "images/13.png",
  "images/101.png",
  "images/102.png"
];  
subjcodeArray[111] = "kindpeople";
